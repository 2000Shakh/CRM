from django.contrib import admin
from.models import *


admin.site.register(Mentor)
admin.site.register(Courses)
admin.site.register(Lesson)
admin.site.register(Student)
admin.site.register(Group)

