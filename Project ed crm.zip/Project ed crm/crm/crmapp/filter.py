import django_filters
from .models import *


class StudentFilter(django_filters.FilterSet):
    class Meta:
        model = Student
        fields = '__all__'
        # exclude = ['full_name', 'birth_date']


class MentorFilter(django_filters.FilterSet):
    class Meta:
        model = Mentor
        fields = '__all__'
