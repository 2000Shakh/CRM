from .import views
from django.urls import path

urlpatterns = (
    path('', views.dashboard, name="dashboard"),
    path('base', views.base, name='base'),
    path('page', views.page, name='page'),
    path('courses', views.add_courses, name='courses'),
    path('add', views.add_student, name='add'),

    path('billing', views.billing, name="billing"),
    path('profile', views.profile, name="profile"),
    path('rtl', views.rtl, name="rtl"),
    path('sign_in', views.sign_in, name="sign_in"),
    path('sign_up', views.sign_up, name="sign_up"),
    path('tables', views.tables, name="tables"),
    path('virtual_reality', views.virtual_reality, name="virtual_reality"),

    path('create_group', views.create_group, name='create_group')
)